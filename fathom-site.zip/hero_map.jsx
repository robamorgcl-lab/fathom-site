/* Hero map animation: a stylized U.S. map with Ohio as origin.
   Payment pulses emit from Ohio outward to holder nodes concentrated on the
   coasts. Soft brass streaks, no crypto glow. 10s loop, auto-starts. */

const { useEffect: useEhm, useState: useShm, useRef: useRhm } = React;

/* Approx lon/lat for anchor cities, projected onto a 1000 x 560 viewbox.
   We use a simple equirectangular-ish mapping calibrated to the simplified
   US outline we draw below (lon -125..-66, lat 24..50). */
const VB_W = 1000;
const VB_H = 560;
const LON_MIN = -125, LON_MAX = -66;
const LAT_MIN = 24,  LAT_MAX = 50;

function project(lon, lat) {
  const x = ((lon - LON_MIN) / (LON_MAX - LON_MIN)) * VB_W;
  // Slight latitude compression for North-leaning look
  const y = ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)) * VB_H;
  return { x, y };
}

const OHIO = project(-82.9, 40.3);

const HOLDERS = [
  // West coast
  { id: "sf",  ...project(-122.4, 37.8), label: "San Francisco", size: 6, delay: 0.15 },
  { id: "la",  ...project(-118.2, 34.0), label: "Los Angeles",   size: 7, delay: 0.25 },
  { id: "sea", ...project(-122.3, 47.6), label: "Seattle",       size: 5, delay: 0.35 },
  { id: "pdx", ...project(-122.7, 45.5), label: "Portland",      size: 4, delay: 0.45 },
  { id: "sd",  ...project(-117.2, 32.7), label: "San Diego",     size: 4, delay: 0.55 },

  // East coast
  { id: "ny",  ...project(-74.0, 40.7),  label: "New York",      size: 8, delay: 0.10 },
  { id: "bos", ...project(-71.1, 42.4),  label: "Boston",        size: 5, delay: 0.30 },
  { id: "dc",  ...project(-77.0, 38.9),  label: "Washington",    size: 6, delay: 0.40 },
  { id: "mia", ...project(-80.2, 25.8),  label: "Miami",         size: 5, delay: 0.50 },
  { id: "atl", ...project(-84.4, 33.7),  label: "Atlanta",       size: 5, delay: 0.60 },
  { id: "cha", ...project(-80.8, 35.2),  label: "Charlotte",     size: 4, delay: 0.65 },
  { id: "phi", ...project(-75.2, 39.95), label: "Philadelphia",  size: 4, delay: 0.20 },

  // Interior anchors
  { id: "chi", ...project(-87.7, 41.9),  label: "Chicago",       size: 6, delay: 0.18 },
  { id: "dal", ...project(-96.8, 32.8),  label: "Dallas",        size: 5, delay: 0.42 },
  { id: "hou", ...project(-95.4, 29.8),  label: "Houston",       size: 5, delay: 0.48 },
  { id: "den", ...project(-105.0, 39.7), label: "Denver",        size: 4, delay: 0.58 },
  { id: "msp", ...project(-93.3, 45.0),  label: "Minneapolis",   size: 4, delay: 0.38 },
];

const LOOP = 10; // seconds
const clampHm = (v, a, b) => Math.max(a, Math.min(b, v));
const smoothHm = (t) => t < 0 ? 0 : t > 1 ? 1 : (t * t * (3 - 2 * t));
const easeOutHm = (t) => 1 - Math.pow(1 - clampHm(t, 0, 1), 3);

/* A single payment "drop" travels from Ohio along an arc to a holder. */
function Pulse({ from, to, t, delay }) {
  // Each pulse repeats with offset. t is loop-local time 0..LOOP.
  const travelDur = 2.2;
  const localT = ((t - delay) % LOOP + LOOP) % LOOP;
  if (localT > travelDur) return null;
  const p = easeOutHm(localT / travelDur);
  // Arc via quadratic midpoint lifted 40% above the chord
  const mx = (from.x + to.x) / 2;
  const my = (from.y + to.y) / 2 - Math.hypot(to.x - from.x, to.y - from.y) * 0.18;
  const x = (1 - p) * (1 - p) * from.x + 2 * (1 - p) * p * mx + p * p * to.x;
  const y = (1 - p) * (1 - p) * from.y + 2 * (1 - p) * p * my + p * p * to.y;
  const op = localT < 0.12 ? localT / 0.12 : (p > 0.92 ? (1 - p) * 12.5 : 0.9);

  return (
    <g opacity={op}>
      <circle cx={x} cy={y} r="4" fill="#C4A574"/>
      <circle cx={x} cy={y} r="8" fill="#C4A574" opacity="0.18"/>
    </g>
  );
}

/* Arc path (static, dashed) from origin to holder, visible at low opacity. */
function ArcPath({ from, to, active }) {
  const mx = (from.x + to.x) / 2;
  const my = (from.y + to.y) / 2 - Math.hypot(to.x - from.x, to.y - from.y) * 0.18;
  const d = `M ${from.x} ${from.y} Q ${mx} ${my} ${to.x} ${to.y}`;
  return (
    <path d={d} fill="none"
          stroke={active ? "#C4A574" : "rgba(245,241,232,0.18)"}
          strokeWidth="1"
          strokeDasharray="2 5"
          opacity={active ? 0.5 : 0.35}/>
  );
}

/* Holder "docked" ping pulse, triggered when a pulse arrives. */
function HolderNode({ holder, t }) {
  // A payment arrives every LOOP seconds, at delay + travelDur
  const arriveAt = holder.delay + 2.2;
  const since = ((t - arriveAt) % LOOP + LOOP) % LOOP;
  const ping = since < 0.8 ? 1 - since / 0.8 : 0;
  return (
    <g transform={`translate(${holder.x}, ${holder.y})`}>
      {/* ping ring */}
      {ping > 0 && (
        <circle r={holder.size + 4 + ping * 10}
                fill="none" stroke="#C4A574" strokeWidth="1"
                opacity={ping * 0.6}/>
      )}
      <circle r={holder.size} fill="#F5F1E8" opacity="0.88"/>
      <circle r={holder.size} fill="none" stroke="#8D6E3F" strokeWidth="1" opacity="0.6"/>
    </g>
  );
}

function OhioOrigin({ t }) {
  // Subtle heartbeat on Ohio every ~LOOP/N seconds, since it emits pulses
  const beat = Math.sin(t * 2.4) * 0.5 + 0.5;
  return (
    <g transform={`translate(${OHIO.x}, ${OHIO.y})`}>
      <circle r={14 + beat * 3} fill="#8D6E3F" opacity="0.14"/>
      <circle r={8} fill="#8D6E3F"/>
      <circle r={4} fill="#F5F1E8"/>
      <text y={-18} textAnchor="middle"
            fontFamily="Inter, sans-serif" fontSize="10" fontWeight="500"
            fill="#C4A574" letterSpacing="0.14em">OHIO BANK</text>
      <text y={24} textAnchor="middle"
            fontFamily="JetBrains Mono, monospace" fontSize="9"
            fill="rgba(245,241,232,0.56)" letterSpacing="0.08em">ORIGINATOR · SERVICING</text>
    </g>
  );
}

function HeroMap() {
  const [t, setT] = useShm(0);
  const [reduced, setReduced] = useShm(false);
  const rafRef = useRhm(null);
  const lastRef = useRhm(null);
  const containerRef = useRhm(null);
  const runningRef = useRhm(true);

  useEhm(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const l = () => setReduced(mq.matches);
    mq.addEventListener?.("change", l);
    return () => mq.removeEventListener?.("change", l);
  }, []);

  useEhm(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      runningRef.current = entry.isIntersecting;
    }, { threshold: 0.05 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEhm(() => {
    if (reduced) { setT(3.0); return; }
    const tick = (ts) => {
      if (lastRef.current == null) lastRef.current = ts;
      const dt = (ts - lastRef.current) / 1000;
      lastRef.current = ts;
      if (runningRef.current) {
        setT(prev => {
          const next = prev + dt;
          return next > LOOP ? next - LOOP : next;
        });
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [reduced]);

  return (
    <div className="hero-map" ref={containerRef}>
      <svg viewBox={`40 80 920 450`} width="100%" height="100%"
           preserveAspectRatio="xMidYMid meet"
           role="img"
           aria-label="U.S. map showing borrower payments flowing from an Ohio bank to tokenized-loan holders on both coasts.">
        <defs>
          <pattern id="heromapgrid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(245,241,232,0.04)" strokeWidth="1"/>
          </pattern>
          <radialGradient id="ohio-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(141,110,63,0.25)"/>
            <stop offset="100%" stopColor="rgba(141,110,63,0)"/>
          </radialGradient>
        </defs>
        <rect x="40" y="80" width="920" height="450" fill="url(#heromapgrid)"/>

        {/* Simplified continental U.S. outline. Hand-drawn path approximating
            the lower 48 within our lon/lat frame. */}
        <g opacity="0.9">
          <path d="
            M 60 230
            L 85 210 L 130 180 L 175 155 L 220 140 L 260 130
            L 310 120 L 360 115 L 410 110 L 470 108 L 540 106
            L 610 106 L 680 108 L 740 112 L 790 118 L 835 130
            L 870 148 L 895 170 L 915 194 L 935 218
            L 945 244 L 945 280 L 938 320 L 930 352
            L 915 380 L 890 404 L 855 425 L 820 442
            L 775 456 L 730 462 L 680 460 L 640 454
            L 600 450 L 560 455 L 520 465 L 480 475
            L 440 478 L 400 472 L 360 460 L 320 448
            L 285 438 L 250 430 L 215 420 L 180 402
            L 150 380 L 125 355 L 105 328 L 88 300
            L 74 270 L 62 248 Z"
            fill="rgba(19,49,92,0.55)"
            stroke="rgba(245,241,232,0.22)"
            strokeWidth="1.2"
            strokeLinejoin="round"/>
          {/* Florida */}
          <path d="M 770 430 L 790 445 L 810 470 L 815 500 L 800 515 L 780 505 L 765 478 L 760 455 Z"
                fill="rgba(19,49,92,0.55)"
                stroke="rgba(245,241,232,0.22)"
                strokeWidth="1.2" strokeLinejoin="round"/>
          {/* Texas bulge subtle indent on bottom line is already in main path */}
          {/* Faint state-lines (a few verticals) */}
          <g stroke="rgba(245,241,232,0.08)" strokeWidth="0.8" strokeDasharray="2 4">
            <line x1="300" y1="120" x2="300" y2="440"/>
            <line x1="430" y1="110" x2="430" y2="470"/>
            <line x1="560" y1="106" x2="560" y2="460"/>
            <line x1="700" y1="110" x2="700" y2="455"/>
            <line x1="820" y1="130" x2="820" y2="430"/>
          </g>
        </g>

        {/* Ohio heat radius under origin */}
        <circle cx={OHIO.x} cy={OHIO.y} r="70" fill="url(#ohio-glow)"/>

        {/* Arc paths (static) */}
        {HOLDERS.map(h => <ArcPath key={`a-${h.id}`} from={OHIO} to={h} active={false}/>)}

        {/* Holder nodes */}
        {HOLDERS.map(h => <HolderNode key={`n-${h.id}`} holder={h} t={t}/>)}

        {/* Origin (Ohio) */}
        <OhioOrigin t={t}/>

        {/* Pulses */}
        {HOLDERS.map(h => <Pulse key={`p-${h.id}`} from={OHIO} to={h} t={t} delay={h.delay}/>)}

        {/* Coast ticks */}
        <g fontFamily="JetBrains Mono, monospace" fontSize="9" fill="rgba(245,241,232,0.44)" letterSpacing="0.1em">
          <text x="60" y="96" textAnchor="start">WEST · 12 HOLDERS</text>
          <text x={VB_W - 40} y="96" textAnchor="end">EAST · 18 HOLDERS</text>
        </g>

        {/* Brass rule under caption */}
        <line x1="60" y1="104" x2="166" y2="104" stroke="#8D6E3F" strokeWidth="1.5" opacity="0.8"/>
        <line x1={VB_W - 146} y1="104" x2={VB_W - 40} y2="104" stroke="#8D6E3F" strokeWidth="1.5" opacity="0.8"/>
      </svg>

      <div className="hero-map-caption">
        <span className="chip">LIVE</span>
        <span className="text">Borrower payments · Ohio &rarr; 30 holders · settling on-chain</span>
      </div>
    </div>
  );
}

window.HeroMap = HeroMap;
