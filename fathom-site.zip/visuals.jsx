/* Market stack + GTM rings visuals. */

const { useEffect: useEffectV, useRef: useRefV, useState: useStateV } = React;

/* --- Market: layered stacked-area chart of U.S. bank loans over 5 years --- */
/*
  Loan categories (rough illustrative allocation; real TAM varies by source):
  - C&I (Commercial & Industrial)  — 2.8T  — beachhead (brass highlight)
  - CRE (Commercial Real Estate)   — 3.2T
  - Consumer (excl. mortgage)      — 1.9T
  - Agricultural                   — 0.2T
  - Residential mortgage           — 2.7T
  Phase 1 addressable: C&I + portions of CRE/Ag.
*/
const LOAN_CATS = [
  { key: "ci",      name: "C&I",           v: "$2.8T", share: 0.242, color: "#8D6E3F", phase: "Phase 1" },
  { key: "cre",     name: "CRE",           v: "$3.2T", share: 0.277, color: "#13315C" },
  { key: "mort",    name: "Residential",   v: "$2.7T", share: 0.233, color: "#1E4379" },
  { key: "cons",    name: "Consumer",      v: "$1.9T", share: 0.164, color: "#3F6B4E" },
  { key: "ag",      name: "Agricultural",  v: "$0.2T", share: 0.017, color: "#6E5530" },
  { key: "other",   name: "Other",         v: "$0.8T", share: 0.067, color: "#6B6B6B" },
];

function MarketVisual() {
  // 5-year growth: base year total 11.6T growing ~4.2% CAGR to ~14.3T by y5
  const years = [0, 1, 2, 3, 4];
  const baseline = 11.6;
  const growth = 1.042;
  const ref = useRefV(null);
  const [p, setP] = useStateV(0);

  useEffectV(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        // animate to 1
        const start = performance.now();
        const duration = 1400;
        const tick = () => {
          const t = Math.min(1, (performance.now() - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          setP(eased);
          if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        obs.disconnect();
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Build stacked series
  const W = 460, H = 320, padL = 40, padR = 10, padT = 20, padB = 34;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;

  const yearTotal = (y) => baseline * Math.pow(growth, y);
  const maxVal = yearTotal(4) * 1.05;

  const xFor = (y) => padL + (y / (years.length - 1)) * innerW;
  const yFor = (v) => padT + (1 - v / maxVal) * innerH;

  // Build cumulative stack per year
  const stack = [];
  let cum = LOAN_CATS.map(() => 0);
  const perYear = years.map(y => {
    const tot = yearTotal(y);
    return LOAN_CATS.map(c => tot * c.share);
  });

  const paths = LOAN_CATS.map((cat, i) => {
    // top path (cumulative with i included) and bottom (cumulative without i)
    const topPts = years.map(y => ({
      x: xFor(y),
      y: yFor(perYear[y].slice(0, i + 1).reduce((a, b) => a + b, 0))
    }));
    const botPts = years.map(y => ({
      x: xFor(y),
      y: yFor(perYear[y].slice(0, i).reduce((a, b) => a + b, 0))
    }));
    const d = [
      `M ${topPts[0].x} ${topPts[0].y}`,
      ...topPts.slice(1).map(pt => `L ${pt.x} ${pt.y}`),
      ...botPts.slice().reverse().map(pt => `L ${pt.x} ${pt.y}`),
      "Z"
    ].join(" ");
    return { ...cat, d, topPts };
  });

  return (
    <div className="market-wrap">
      <div>
        <div className="market-stack" ref={ref}>
          <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%">
            {/* Y axis grid */}
            {[0, 4, 8, 12, 16].map(v => (
              <g key={v}>
                <line x1={padL} x2={W - padR} y1={yFor(v)} y2={yFor(v)}
                      stroke="#DDD4BD" strokeWidth="1"/>
                <text x={padL - 8} y={yFor(v) + 4} fontFamily="JetBrains Mono, monospace"
                      fontSize="10" fill="#6B6B6B" textAnchor="end">${v}T</text>
              </g>
            ))}

            {/* stacked areas, clipped by progress */}
            <defs>
              <clipPath id="grow">
                <rect x={padL} y="0" width={innerW * p} height={H}/>
              </clipPath>
            </defs>

            <g clipPath="url(#grow)">
              {paths.map(pp => (
                <path key={pp.key} d={pp.d}
                      fill={pp.color}
                      fillOpacity={pp.key === "ci" ? 0.96 : 0.82}
                      stroke="#F5F1E8" strokeWidth="0.5"/>
              ))}
              {/* C&I callout ring on top line */}
              {(() => {
                const pp = paths.find(x => x.key === "ci");
                const last = pp.topPts[pp.topPts.length - 1];
                return (
                  <g>
                    <line x1={last.x} y1={last.y} x2={last.x} y2={last.y - 40}
                          stroke="#8D6E3F" strokeWidth="1" opacity={p}/>
                  </g>
                );
              })()}
            </g>

            {/* X axis labels */}
            {years.map(y => (
              <text key={y} x={xFor(y)} y={H - 14}
                    fontFamily="JetBrains Mono, monospace"
                    fontSize="10" fill="#6B6B6B" textAnchor="middle">
                {`Y${y}`}
              </text>
            ))}

            {/* Beachhead brass-underline for phase 1 */}
            <line x1={padL} x2={xFor(1)} y1={H - padB + 14} y2={H - padB + 14}
                  stroke="#8D6E3F" strokeWidth="2" opacity={p}/>

            <text x={padL + 2} y={padT + 14}
                  fontFamily="Inter, sans-serif" fontSize="10" fontWeight="500"
                  fill="#8D6E3F" letterSpacing="0.12em">
              U.S. BANK LOANS · TOTAL ${yearTotal(4).toFixed(1)}T BY Y5
            </text>
          </svg>
        </div>
      </div>

      <div>
        <div className="market-legend">
          {LOAN_CATS.map((c, i) => (
            <div key={c.key} className="row">
              <div className="swatch" style={{ background: c.color }}/>
              <div className="name">
                {c.name}
                {c.phase && <span className="tag">{c.phase} · Beachhead</span>}
              </div>
              <div className="v">{c.v}</div>
              <div className="share">{(c.share * 100).toFixed(1)}%</div>
            </div>
          ))}
        </div>
        <p style={{ marginTop: 24, fontSize: 13, color: "var(--fg-3)", lineHeight: 1.55, maxWidth: 440 }}>
          Business loans carry the lightest regulatory friction — our first-wave focus.
          Consumer and mortgage unlock in later phases as tokenized-RWA rules mature.
        </p>
      </div>
    </div>
  );
}

/* --- GTM: concentric rings --- */
function GtmRings() {
  const ref = useRefV(null);
  const [p, setP] = useStateV(0);
  useEffectV(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        const start = performance.now();
        const duration = 1800;
        const tick = () => {
          const t = Math.min(1, (performance.now() - start) / duration);
          setP(1 - Math.pow(1 - t, 3));
          if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        obs.disconnect();
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const cx = 260, cy = 260;
  // Three distinct ring BANDS: inner radius -> outer radius
  const bands = [
    { rIn: 54,  rOut: 108, label: "Pilot banks",                 count: "6–10",      nodes: 8,  phase: 0.10, tint: "rgba(196,165,116,0.26)", edge: "#C4A574", dotSize: 5.5 },
    { rIn: 118, rOut: 168, label: "State associations",          count: "50 states", nodes: 14, phase: 0.40, tint: "rgba(245,241,232,0.07)",  edge: "rgba(245,241,232,0.55)", dotSize: 4.5 },
    { rIn: 178, rOut: 228, label: "Regionals + correspondents",  count: "600+ banks", nodes: 22, phase: 0.72, tint: "rgba(245,241,232,0.035)", edge: "rgba(245,241,232,0.32)", dotSize: 3.5 },
  ];

  return (
    <div className="gtm-rings" ref={ref}>
      <svg viewBox="0 0 520 520" width="100%" height="100%">
        <defs>
          <radialGradient id="ringCore" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(141,110,63,0.22)"/>
            <stop offset="100%" stopColor="rgba(141,110,63,0)"/>
          </radialGradient>
        </defs>

        {/* Core glow behind center */}
        <circle cx={cx} cy={cy} r="240" fill="url(#ringCore)"/>

        {/* Banded rings: outer-to-inner so inner bands paint on top */}
        {[...bands].reverse().map((b, idx) => {
          const i = bands.length - 1 - idx;
          const reach = Math.max(0, Math.min(1, (p - b.phase) / 0.25));
          // Scale band outward as reach goes 0 -> 1
          const rOut = b.rOut * reach;
          const rIn  = b.rIn  * reach;
          if (reach <= 0) return null;
          return (
            <g key={`band-${i}`}>
              {/* Fill band as a donut using even-odd fill-rule */}
              <path
                d={`M ${cx - rOut} ${cy} a ${rOut} ${rOut} 0 1 0 ${rOut * 2} 0 a ${rOut} ${rOut} 0 1 0 -${rOut * 2} 0 M ${cx - rIn} ${cy} a ${rIn} ${rIn} 0 1 0 ${rIn * 2} 0 a ${rIn} ${rIn} 0 1 0 -${rIn * 2} 0`}
                fill={b.tint}
                fillRule="evenodd"
              />
              {/* Inner + outer edges of band: solid outer, dashed inner */}
              <circle cx={cx} cy={cy} r={rOut} fill="none" stroke={b.edge} strokeWidth="1.25" opacity={0.9}/>
              <circle cx={cx} cy={cy} r={rIn}  fill="none" stroke={b.edge} strokeWidth="1"    opacity={0.35} strokeDasharray="3 5"/>
            </g>
          );
        })}

        {/* Nodes drawn on the midline of each band */}
        {bands.map((b, i) => {
          const reach = Math.max(0, Math.min(1, (p - b.phase) / 0.25));
          if (reach <= 0) return null;
          const rMid = ((b.rIn + b.rOut) / 2) * reach;
          const nodes = Array.from({ length: b.nodes }).map((_, k) => {
            const theta = (k / b.nodes) * Math.PI * 2 - Math.PI / 2 + (i * 0.12);
            const x = cx + Math.cos(theta) * rMid;
            const y = cy + Math.sin(theta) * rMid;
            return (
              <g key={k}>
                <circle cx={x} cy={y} r={b.dotSize}
                        fill={i === 0 ? "#C4A574" : "#F5F1E8"}
                        opacity={i === 0 ? 1 : 0.82 - i * 0.12}/>
                {i === 0 && (
                  <circle cx={x} cy={y} r={b.dotSize + 3}
                          fill="none" stroke="#C4A574" strokeWidth="1" opacity="0.35"/>
                )}
              </g>
            );
          });
          return <g key={`n-${i}`}>{nodes}</g>;
        })}

        {/* Center: Fathom */}
        <circle cx={cx} cy={cy} r="44" fill="#0B2545" stroke="#8D6E3F" strokeWidth="2"/>
        <circle cx={cx} cy={cy} r="48" fill="none" stroke="#C4A574" strokeWidth="1" opacity="0.4" strokeDasharray="2 4"/>
        <g transform={`translate(${cx - 15}, ${cy - 11})`}>
          <rect width="20" height="2.5" fill="#F5F1E8"/>
          <rect y="6" width="13" height="2.5" fill="#F5F1E8"/>
          <rect y="12" width="30" height="2.5" fill="#C4A574"/>
          <rect y="18" width="16" height="2.5" fill="#F5F1E8"/>
        </g>

        {/* Ring labels, positioned on the outer edge of each band */}
        {bands.map((b, i) => {
          const reach = Math.max(0, Math.min(1, (p - b.phase) / 0.25));
          const labelY = cy - b.rOut - 10;
          return (
            <g key={`lbl-${i}`} opacity={reach} transform={`translate(${cx}, ${labelY})`}>
              <text textAnchor="middle"
                    fontFamily="Inter, sans-serif" fontSize="11" fontWeight="500"
                    fill={i === 0 ? "#C4A574" : "rgba(245,241,232,0.82)"}
                    letterSpacing="0.14em"
                    style={{ textTransform: "uppercase" }}>
                {b.label}
              </text>
              <text textAnchor="middle" y="14"
                    fontFamily="JetBrains Mono, monospace" fontSize="10"
                    fill="rgba(245,241,232,0.56)">
                {b.count}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

window.MarketVisual = MarketVisual;
window.GtmRings = GtmRings;
