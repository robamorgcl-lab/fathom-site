/* Main app: shell, nav, all 9 sections. */

const { useEffect: useE, useState: useS, useRef: useR } = React;

function Nav() {
  const [scrolled, setScrolled] = useS(false);
  const [onCream, setOnCream] = useS(false);

  useE(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      // Detect if we've scrolled past the hero (which is min-height 100vh)
      setOnCream(y > window.innerHeight * 0.7);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav className={`nav ${scrolled ? "scrolled" : ""} ${onCream ? "on-cream" : ""}`}>
      <a href="#top" className="nav-logo" aria-label="Fathom, home">
        <svg className="mark-bars" viewBox="0 0 52 37" aria-hidden="true">
          <rect width="36" height="4"/>
          <rect y="11" width="22" height="4"/>
          <rect y="22" width="52" height="4" className="mid"/>
          <rect y="33" width="28" height="4"/>
        </svg>
        <span>Fathom</span>
      </a>
      <a href="#cta" className="btn primary" style={{ padding: "10px 18px", fontSize: 13 }}>
        Request investor materials
        <span className="arrow" aria-hidden="true">→</span>
      </a>
    </nav>
  );
}

function Reveal({ children, delay = 0, as: As = "div", ...rest }) {
  const ref = useR(null);
  const [inView, setInView] = useS(false);
  useE(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setTimeout(() => setInView(true), delay);
        obs.disconnect();
      }
    }, { threshold: 0.15 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [delay]);
  return (
    <As ref={ref} className={`reveal ${inView ? "in" : ""} ${rest.className || ""}`} {...rest}>
      {children}
    </As>
  );
}

function Eyebrow({ num, label }) {
  return (
    <div className="eyebrow">
      <span>{String(num).length === 1 ? `0${num}` : num}</span>
      <span className="sep">·</span>
      <span className="tracked">{label}</span>
    </div>
  );
}

function Hero() {
  return (
    <header className="hero" id="top">
      <div className="hero-bg" aria-hidden="true"/>
      <div className="container">
        <div className="hero-content">
          <div className="hero-copy">
            <div className="hero-brass-rule"/>
            <Eyebrow num="1" label="FATHOM"/>
            <h1 style={{ marginTop: 32 }}>
              Tokenize assets,<br/>
              <span className="accent">not liabilities.</span>
            </h1>
            <p className="lead">
              Fathom is the settlement layer for U.S. bank loans. Community and regional
              banks originate, syndicate, and settle participations on-chain, in hours,
              not weeks.
            </p>
            <div className="hero-cta-row">
              <a href="#cta" className="btn primary">
                Request investor materials
                <span className="arrow" aria-hidden="true">→</span>
              </a>
              <a href="#solution" className="btn ghost">
                See how it works
              </a>
            </div>
          </div>
          <div className="hero-map-wrap">
            <window.HeroMap/>
          </div>
        </div>
        <div className="hero-stat-row">
          <div className="stats">
            <div className="stat">
              <div className="k">$11.6T</div>
              <div className="l">U.S. BANK LOANS OUTSTANDING</div>
            </div>
            <div className="stat">
              <div className="k">4,500+</div>
              <div className="l">COMMUNITY &amp; REGIONAL BANKS</div>
            </div>
            <div className="stat">
              <div className="k">7–14 days</div>
              <div className="l">TODAY&rsquo;S PARTICIPATION CLOSE</div>
            </div>
            <div className="stat">
              <div className="k">&lt; 4 hours</div>
              <div className="l">ON FATHOM, ON-CHAIN</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Problem() {
  const items = [
    {
      idx: "2.1",
      h: "Stablecoins are draining deposits.",
      p: "Tokenized dollars now move on rails banks don't own. Midsize, regional, and community banks are feeling real funding pressure for the first time in over a decade.",
      micro: "~$240B stablecoin supply · growing 30%+ annually",
    },
    {
      idx: "2.2",
      h: "Issuing your own stablecoin doesn't fix it.",
      p: "A bank-issued stablecoin has no native demand. Without a use case, it's a brand exercise that doesn't offset the deposits walking out the door.",
      micro: "Nine bank-led stablecoin pilots · zero meaningful adoption",
    },
    {
      idx: "2.3",
      h: "Stablecoin holders have nowhere safe to earn.",
      p: "Converting back to USD is high-friction. On-chain yields carry poor risk-adjusted returns. Real bank credit — the asset side of the balance sheet — is unreachable.",
      micro: "Institutional capital · waiting for bank-grade on-chain yield",
    },
  ];
  return (
    <section className="section" id="problem">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="2" label="THE PROBLEM"/>
          <h2>Every stablecoin in circulation is a tokenized <span className="accent">liability.</span></h2>
          <p className="lead">
            Tokenization arrived, and it arrived on the wrong side of the balance sheet.
            Deposits are migrating on-chain. Loans, the productive side, are not.
          </p>
        </Reveal>
        <Reveal>
          <div className="problem-grid">
            {items.map(it => (
              <div key={it.idx} className="problem-card">
                <div className="idx">PROBLEM · {it.idx}</div>
                <h3>{it.h}</h3>
                <p>{it.p}</p>
                <div className="micro">{it.micro}</div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Solution() {
  return (
    <section className="section dark" id="solution">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="3" label="THE SOLUTION"/>
          <h2>Fathom tokenizes <span className="accent">the other side</span> of the balance sheet.</h2>
          <p className="lead">
            A community bank in Ohio can sell 75% of a commercial loan to three peer
            institutions by Tuesday, keep the servicing relationship, and receive payments
            on the retained piece automatically. The mechanics are participations — banks
            have done them for a century. The settlement is on-chain, which is why it
            clears in hours instead of weeks.
          </p>
        </Reveal>
        <Reveal delay={120}>
          <window.FlowAnimation/>
        </Reveal>
      </div>
    </section>
  );
}

function ForBanks() {
  const pillars = [
    {
      tag: "EXPAND LENDING",
      h: "Solve funding pressure.",
      p: "A liquid secondary market recycles balance sheet in hours, not quarters.",
      icon: (
        <svg viewBox="0 0 48 48" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M 8 36 L 8 12 M 14 36 L 14 18 M 20 36 L 20 14 M 26 36 L 26 20 M 32 36 L 32 10 M 38 36 L 38 16"/>
          <path d="M 4 40 L 44 40"/>
          <path d="M 32 6 L 36 10 L 32 14"/>
        </svg>
      ),
    },
    {
      tag: "KEEP DEPOSITS IN-SYSTEM",
      h: "Issue a stablecoin with a purpose.",
      p: "Bank-issued, deposit-backed, and productive inside the rail you already use.",
      icon: (
        <svg viewBox="0 0 48 48" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <rect x="8" y="10" width="32" height="28" rx="1"/>
          <path d="M 8 18 L 40 18"/>
          <circle cx="24" cy="28" r="5"/>
          <path d="M 24 25 L 24 31 M 21 28 L 27 28"/>
        </svg>
      ),
    },
    {
      tag: "COMMUNITY FIRST",
      h: "Keep the borrower relationship.",
      p: "Originate, retain servicing, and stay the bank your community already trusts.",
      icon: (
        <svg viewBox="0 0 48 48" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M 8 38 L 8 22 L 16 16 L 24 22 L 24 38 Z"/>
          <path d="M 24 38 L 24 26 L 32 20 L 40 26 L 40 38 Z"/>
          <path d="M 4 38 L 44 38"/>
          <path d="M 13 38 L 13 30 L 19 30 L 19 38"/>
          <path d="M 29 38 L 29 32 L 35 32 L 35 38"/>
        </svg>
      ),
    },
  ];
  return (
    <section className="banner-banks" id="for-banks">
      <div className="container">
        <Reveal>
          <div className="banks-banner-head">
            <Eyebrow num="4" label="FOR BANKS"/>
            <h2>A rail built <span className="accent">for community and regional banks</span>, not around them.</h2>
          </div>
        </Reveal>
        <Reveal>
          <div className="banks-banner-grid">
            {pillars.map((p, i) => (
              <div key={i} className="bank-ic">
                <div className="bank-ic-icon" aria-hidden="true">{p.icon}</div>
                <div className="bank-ic-body">
                  <div className="bank-ic-tag">{p.tag}</div>
                  <h3>{p.h}</h3>
                  <p>{p.p}</p>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function WhyNow() {
  const items = [
    {
      k: "5.1",
      h: "Stablecoins hit institutional escape velocity.",
      p: "Treasuries now clear stablecoin settlement. BlackRock, Franklin Templeton, and JPMorgan operate on tokenized rails. The plumbing is no longer hypothetical.",
      n: "$240B",
      d: "stablecoin supply · 30% YoY growth",
    },
    {
      k: "5.2",
      h: "OCC opens the door for banks.",
      p: "OCC Interpretive Letter 1184 affirms that national banks may custody crypto assets, run stablecoin activities, and participate in independent node verification networks. The regulatory perimeter banks needed is here.",
      n: "IL · 1184",
      d: "OCC guidance · banks cleared for on-chain activity",
    },
    {
      k: "5.3",
      h: "Community banks are squeezed.",
      p: "Deposit flight, thin NIMs, and concentrated CRE exposure. Acting as a network — distributing risk to peers — is the only leverage they have left.",
      n: "4,500+",
      d: "community &amp; regional banks · fleet, not flagship",
    },
  ];
  return (
    <section className="section" id="why-now">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="5" label="WHY NOW"/>
          <h2>Three curves <span className="accent">crossing</span> at the same moment.</h2>
        </Reveal>
        <div className="why-grid">
          {items.map((it, i) => (
            <Reveal key={it.k} delay={i * 80}>
              <div className="why-card">
                <div className="kicker">FORCE · {it.k}</div>
                <h3>{it.h}</h3>
                <p>{it.p}</p>
                <div className="datum">
                  <div className="n">{it.n}</div>
                  <div className="d" dangerouslySetInnerHTML={{ __html: it.d }}/>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Roadmap() {
  const ref = useR(null);
  const [filled, setFilled] = useS(false);
  useE(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setFilled(true); obs.disconnect(); }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  const phases = [
    {
      n: "PHASE · 01",
      h: "Bank-to-bank participations.",
      p: "A small invited network of community and regional banks. Originations settled on a permissioned chain. The 75/25 split, automated end-to-end.",
      chip: "Live · beachhead",
    },
    {
      n: "PHASE · 02",
      h: "Institutional capital enters.",
      p: "Credit funds, insurance balance sheets, and family offices buy tokenized participations alongside banks. Fathom runs the secondary market.",
      chip: "2027 · gated access",
    },
    {
      n: "PHASE · 03",
      h: "Public chains, trapped liquidity released.",
      p: "Tokenized loans listed on public L1s and L2s with bank-grade disclosure. Stablecoin holders finally reach real credit — through the rail banks already trust.",
      chip: "2028+ · open rails",
    },
  ];
  return (
    <section className="section" id="roadmap">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="6" label="HOW IT WORKS"/>
          <h2>One product. <span className="accent">Three phases</span> of reach.</h2>
        </Reveal>
        <Reveal>
          <div className="roadmap-rule" style={{ "--fill": filled ? "100%" : "0%" }} ref={ref}/>
          <div className="roadmap">
            {phases.map((ph, i) => (
              <div key={i} className="phase">
                <div className="dot"/>
                <div className="ph">{ph.n}</div>
                <h3>{ph.h}</h3>
                <p>{ph.p}</p>
                <span className="chip">{ph.chip}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Market() {
  return (
    <section className="section" id="market" style={{ background: "var(--cream-deep)" }}>
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="7" label="THE MARKET"/>
          <h2>$14.3 trillion in U.S. bank loans <span className="accent">by Y5.</span></h2>
          <p className="lead">
            We don't need the whole market. Commercial &amp; industrial credit is the
            first beachhead — lightest regulatory friction, highest peer-participation
            culture, cleanest settlement.
          </p>
        </Reveal>
        <Reveal>
          <window.MarketVisual/>
        </Reveal>
      </div>
    </section>
  );
}

function Gtm() {
  return (
    <section className="section dark" id="gtm">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="8" label="GO TO MARKET"/>
          <h2>Land small. Expand <span className="accent">through the network</span> banks already trust.</h2>
        </Reveal>
        <div className="gtm-wrap">
          <Reveal>
            <window.GtmRings/>
          </Reveal>
          <Reveal delay={120}>
            <div className="gtm-steps">
              <div className="gtm-step">
                <div className="num">01</div>
                <div>
                  <h3>Land with 6–10 pilot banks.</h3>
                  <p>Concierge onboarding. Operator console, custody, and the first clean participation rail. Every pilot signs a reference commitment.</p>
                </div>
              </div>
              <div className="gtm-step">
                <div className="num">02</div>
                <div>
                  <h3>Expand through state associations.</h3>
                  <p>State banking associations are the trust layer. One endorsement per state unlocks 40–200 member banks. Fleet, not flagship.</p>
                </div>
              </div>
              <div className="gtm-step">
                <div className="num">03</div>
                <div>
                  <h3>Layer in regionals and correspondents.</h3>
                  <p>Correspondent banks bring their downstream relationships with them. One large regional means 50–100 community banks flip on by default.</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function BusinessModel() {
  // Hypothetical: $10M commercial loan at 75% LTV, 7.5% coupon, 5yr term.
  // Fathom earns three fees across the life of the loan.
  const loan = {
    principal: 10_000_000,
    ltv: "75%",
    coupon: "7.50%",
    term: "5 yr",
  };
  const fees = [
    {
      tag: "01 · ORIGINATION",
      h: "Origination fee",
      bps: 15,
      amount: 15_000,
      of: "on principal",
      p: "Charged once when the loan is tokenized and sold down to peer participants. Paid by the originating bank out of improved syndication economics.",
      math: "$10,000,000 × 15 bps",
    },
    {
      tag: "02 · SECONDARY",
      h: "Trading fee",
      bps: 8,
      amount: 6_000,
      of: "per turnover · assumes participations trade 75% annualized",
      p: "Applied each time a tokenized participation changes hands on the secondary market. Matches the conventions of existing institutional credit secondaries.",
      math: "$7,500,000 sold · 8 bps · 1.0× turnover",
    },
    {
      tag: "03 · SERVICING",
      h: "Borrower payment fee",
      bps: 5,
      amount: 37_500,
      of: "on annual debt service",
      p: "Collected as interest and principal flow through the rail from the borrower to participants. A thin take on cashflows already settling on-chain.",
      math: "~$750,000 annual P&I × 5 bps · 5yr term",
    },
  ];
  const totalLife = fees.reduce((s, f) => s + f.amount, 0);
  const fmt = (n) => "$" + n.toLocaleString();

  return (
    <section className="section" id="model">
      <div className="container">
        <Reveal className="section-head">
          <Eyebrow num="9" label="BUSINESS MODEL"/>
          <h2>Three thin takes on <span className="accent">one $10M loan.</span></h2>
          <p className="lead">
            A worked example. Fathom earns on origination, secondary trading, and borrower payments. Pricing mirrors conventions banks already understand.
          </p>
        </Reveal>

        <Reveal>
          <div className="loan-card">
            <div className="loan-header">
              <div className="loan-label">HYPOTHETICAL · COMMERCIAL LOAN</div>
              <div className="loan-stats">
                <div><span className="s-val">$10.0M</span><span className="s-lab">PRINCIPAL</span></div>
                <div><span className="s-val">{loan.ltv}</span><span className="s-lab">LTV</span></div>
                <div><span className="s-val">{loan.coupon}</span><span className="s-lab">COUPON</span></div>
                <div><span className="s-val">{loan.term}</span><span className="s-lab">TERM</span></div>
              </div>
            </div>

            <div className="fee-grid">
              {fees.map((f, i) => (
                <div key={i} className="fee-card">
                  <div className="fee-tag">{f.tag}</div>
                  <h3>{f.h}</h3>
                  <div className="fee-rate">
                    <span className="bps">{f.bps}</span>
                    <span className="unit">bps</span>
                    <span className="of">{f.of}</span>
                  </div>
                  <div className="fee-math">{f.math}</div>
                  <div className="fee-amount">
                    <span className="a">{fmt(f.amount)}</span>
                    <span className="al">FATHOM REVENUE · {i === 2 ? "LIFE OF LOAN" : i === 1 ? "ANNUAL" : "ONE-TIME"}</span>
                  </div>
                  <p>{f.p}</p>
                </div>
              ))}
            </div>

            <div className="loan-total">
              <div className="total-left">
                <div className="total-lab">FATHOM REVENUE · LIFE OF LOAN</div>
                <div className="total-sub">Origination + 5yr of trading + 5yr of payments on a single $10M loan.</div>
              </div>
              <div className="total-right">
                <div className="total-num">{fmt(totalLife + 6_000 * 4 + 37_500 * 4)}</div>
                <div className="total-note">~58 bps of principal · compounds with every additional loan on the rail</div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Closing() {
  return (
    <section className="close-cta" id="cta">
      <div className="container">
        <Reveal>
          <Eyebrow num="10" label="RAISING"/>
          <h2 style={{ marginTop: 40 }}>Fathom is raising a seed round to ship Phase 1 with its pilot banks.</h2>
          <p className="lead">
            We're sharing the full investor memo, pilot bank LOIs, regulatory memo, and
            financial model with a tight list of institutional leads.
          </p>
          <a href="mailto:investors@fathom.finance?subject=Fathom%20investor%20materials" className="btn primary" style={{ fontSize: 15, padding: "14px 28px" }}>
            Request investor materials
            <span className="arrow" aria-hidden="true">→</span>
          </a>
          <div className="contact">
            Direct: <a href="mailto:rob@fathom.finance">rob@fathom.finance</a> · +1 415 555 0117
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container row">
        <div>© 2026 Fathom Financial, Inc. · Wilmington, DE</div>
        <div>Tokenize assets, not liabilities.</div>
      </div>
    </footer>
  );
}

function App() {
  return (
    <>
      <Nav/>
      <Hero/>
      <Problem/>
      <Solution/>
      <ForBanks/>
      <WhyNow/>
      <Roadmap/>
      <Market/>
      <Gtm/>
      <BusinessModel/>
      <Closing/>
      <Footer/>
    </>
  );
}

window.App = App;
