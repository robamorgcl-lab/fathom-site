/* Flow animation — the centerpiece.
   Bank A on the left originates a loan token; 3 shards travel to Banks B/C/D
   stacked VERTICALLY on the right. Then a borrower payment enters A, converts
   to USD stablecoin, flows out in proportion. 14s loop. */

const { useEffect, useState, useRef } = React;

const TL = {
  originate:   { start: 0.4, end: 2.2 },
  split:       { start: 2.2, end: 3.2 },
  travel:      { start: 3.2, end: 5.2 },
  dock:        { start: 5.2, end: 6.0 },
  pausePay:    { start: 6.0, end: 7.0 },
  borrowerPay: { start: 7.0, end: 8.4 },
  stableMint:  { start: 8.4, end: 9.2 },
  stableFlow:  { start: 9.2, end: 11.6 },
  settled:     { start: 11.6, end: 13.0 },
  reset:       { start: 13.0, end: 14.0 },
};
const LOOP_DURATION = 14;

/* ---- Geometry ----
   ViewBox 900 x 620. Bank A centered on the left. Banks B, C, D stacked on
   the right at three vertical positions.                                 */
const NODES = [
  { id: "A", x: 180, y: 310, label: "Bank A", sub: "Originating Bank",    pct: 25 },
  { id: "B", x: 720, y: 130, label: "Bank B", sub: "Participant",         pct: 25 },
  { id: "C", x: 720, y: 310, label: "Bank C", sub: "Participant",         pct: 25 },
  { id: "D", x: 720, y: 490, label: "Bank D", sub: "Participant",         pct: 25 },
];
const TOKEN_ORIGIN = { x: 180, y: 140 };

/* Unified trunk X for the org-chart routing between Bank A and B/C/D. */
const TRUNK_X = 450;

/* Walk a 3-segment orthogonal path at progress t (0..1), returning {x, y}.
   Segment lengths are in proportion to their distance, so motion is even. */
function orgPoint(from, to, t, trunkX) {
  const tx = trunkX != null ? trunkX : (from.x + to.x) / 2;
  const s1 = Math.abs(tx - from.x);
  const s2 = Math.abs(to.y - from.y);
  const s3 = Math.abs(to.x - tx);
  const total = s1 + s2 + s3 || 1;
  const d = t * total;
  if (d <= s1) {
    return { x: from.x + (tx - from.x) * (d / s1 || 0), y: from.y };
  } else if (d <= s1 + s2) {
    return { x: tx, y: from.y + (to.y - from.y) * ((d - s1) / s2 || 0) };
  } else {
    return { x: tx + (to.x - tx) * ((d - s1 - s2) / s3 || 0), y: to.y };
  }
}

const PHASE_LABELS = [
  { t0: 0.4,  t1: 2.4,  n: "1",  text: "Loan originated" },
  { t0: 2.4,  t1: 6.0,  n: "2",  text: "Participations sold · 75/25 split" },
  { t0: 6.5,  t1: 8.6,  n: "3",  text: "Borrower payment received" },
  { t0: 8.6,  t1: 12.0, n: "4",  text: "USD distributed to holders" },
  { t0: 12.0, t1: 13.8, n: "✓",  text: "Cleared in hours, not weeks" },
];

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ease = (t) => t < 0 ? 0 : t > 1 ? 1 : (t * t * (3 - 2 * t));
const easeOut = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
const easeIn = (t) => Math.pow(clamp(t, 0, 1), 2);

function phaseProgress(time, { start, end }) {
  if (time < start) return 0;
  if (time > end) return 1;
  return (time - start) / (end - start);
}

function Node({ node, time }) {
  const isA = node.id === "A";
  const glow = isA ? ease(phaseProgress(time, TL.originate)) * 0.6 : 0;
  return (
    <g transform={`translate(${node.x},${node.y})`}>
      <ellipse cx="0" cy="62" rx="70" ry="6" fill="rgba(0,0,0,0.24)" />
      <g>
        <rect x="-58" y="-8" width="116" height="72" rx="2"
              fill="#0F2A52" stroke="rgba(245,241,232,0.18)" strokeWidth="1"/>
        <rect x="-44" y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <rect x="-28" y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <rect x="-12" y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <rect x="4"   y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <rect x="20"  y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <rect x="36"  y="6" width="4" height="44" fill="rgba(245,241,232,0.22)"/>
        <polygon points="-62,-8 62,-8 0,-28" fill="#0F2A52" stroke="rgba(245,241,232,0.18)" strokeWidth="1"/>
        <rect x="-62" y="50" width="124" height="2" fill={isA && glow > 0.1 ? "#C4A574" : "#8D6E3F"}
              opacity={isA ? 0.4 + glow : 0.6}/>
      </g>
      <text y="90" textAnchor="middle"
            fontFamily="Source Serif 4, Georgia, serif"
            fontSize="18" fontWeight="500"
            fill="#F5F1E8" letterSpacing="-0.01em">{node.label}</text>
      <text y="108" textAnchor="middle"
            fontFamily="Inter, sans-serif"
            fontSize="11" fill="rgba(245,241,232,0.56)"
            letterSpacing="0.04em">{node.sub}</text>
      <PctTag time={time} pct={node.pct} isOriginator={isA} />
    </g>
  );
}

function PctTag({ time, pct, isOriginator }) {
  let op;
  if (isOriginator) {
    op = ease(phaseProgress(time, TL.originate));
    if (time > 13.2) op *= ease(1 - (time - 13.2) / 0.8);
  } else {
    op = ease(phaseProgress(time, TL.dock));
    if (time > 13.2) op *= ease(1 - (time - 13.2) / 0.8);
  }
  if (op < 0.02) return null;
  return (
    <g opacity={op} transform="translate(0, -46)">
      <rect x="-26" y="-11" width="52" height="22" rx="2" fill="#8D6E3F"/>
      <text textAnchor="middle" y="4"
            fontFamily="JetBrains Mono, monospace"
            fontSize="12" fontWeight="500" fill="#F5F1E8">{pct}%</text>
    </g>
  );
}

/* Org-chart orthogonal path from an origin to a target: goes right from the
   origin to a vertical trunk, then up/down, then right into the target. */
function orgPath(from, to, trunkX) {
  const tx = trunkX != null ? trunkX : (from.x + to.x) / 2;
  return `M ${from.x} ${from.y} L ${tx} ${from.y} L ${tx} ${to.y} L ${to.x} ${to.y}`;
}

function Rail({ from, to, trunkX, time }) {
  const mountP = ease(phaseProgress(time, { start: TL.split.start, end: TL.split.end + 0.3 }));
  const flowP = ease(phaseProgress(time, TL.stableFlow));
  const baseOp = 0.12 + 0.12 * mountP;
  const highlightOp = 0.0 + 0.35 * flowP * (1 - Math.abs(flowP - 0.5) * 1.2);
  const d = orgPath(from, to, trunkX);
  return (
    <g>
      <path d={d} fill="none"
            stroke="rgba(245,241,232,1)" strokeWidth="1"
            opacity={baseOp} strokeDasharray="2 4"/>
      <path d={d} fill="none"
            stroke="#C4A574" strokeWidth="1.5"
            opacity={Math.max(0, highlightOp)}/>
      {/* Junction dot at the trunk-to-branch joint */}
      <circle cx={trunkX != null ? trunkX : (from.x + to.x) / 2} cy={to.y} r="2"
              fill="#8D6E3F" opacity={baseOp * 2}/>
    </g>
  );
}

function LoanToken({ time }) {
  const appearP = easeOut(phaseProgress(time, TL.originate));
  const splitP = ease(phaseProgress(time, TL.split));
  if (time > TL.split.end + 0.05) return null;
  const scale = 0.2 + 0.8 * appearP;
  const bob = Math.sin(time * 2) * 2 * appearP;
  const fadeOut = 1 - splitP;
  return (
    <g transform={`translate(${TOKEN_ORIGIN.x}, ${TOKEN_ORIGIN.y + bob}) scale(${scale})`} opacity={fadeOut * appearP}>
      <circle r="56" fill="#8D6E3F" opacity="0.14" />
      <circle r="40" fill="#8D6E3F" opacity="0.22" />
      <polygon points="0,-30 26,-15 26,15 0,30 -26,15 -26,-15"
               fill="#13315C" stroke="#8D6E3F" strokeWidth="2"/>
      <polygon points="0,-22 19,-11 19,11 0,22 -19,11 -19,-11"
               fill="none" stroke="rgba(196,165,116,0.5)" strokeWidth="1"/>
      <text textAnchor="middle" y="5"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11" fontWeight="500" fill="#C4A574"
            letterSpacing="0.1em">LOAN</text>
    </g>
  );
}

function Shards({ time }) {
  const splitP = ease(phaseProgress(time, TL.split));
  if (time < TL.split.start - 0.05) return null;
  if (time > TL.dock.end + 0.25) return null;
  const travelP = easeOut(phaseProgress(time, TL.travel));
  const fadeIn = splitP;
  // Shards start at Bank A (the "rail origin" — same point the rails leave from)
  const railOrigin = { x: NODES[0].x, y: NODES[0].y - 60 };
  const perches = {
    B: { x: NODES[1].x, y: NODES[1].y - 60 },
    C: { x: NODES[2].x, y: NODES[2].y - 60 },
    D: { x: NODES[3].x, y: NODES[3].y - 60 },
  };
  // "A" retains its own 25% above Bank A (no travel)
  return (
    <g>
      {/* Bank A's 25%: static shard above A */}
      <g transform={`translate(${NODES[0].x}, ${NODES[0].y - 100})`}
         opacity={fadeIn * (1 - ease(phaseProgress(time, { start: TL.dock.end - 0.2, end: TL.dock.end + 0.2 })) * 0.6)}>
        <circle r="18" fill="#8D6E3F" opacity="0.18"/>
        <rect x="-14" y="-14" width="28" height="28" rx="2"
              fill="#13315C" stroke="#8D6E3F" strokeWidth="1.5"/>
        <text textAnchor="middle" y="4"
              fontFamily="JetBrains Mono, monospace"
              fontSize="10" fontWeight="500" fill="#C4A574">25%</text>
      </g>
      {["B", "C", "D"].map((id) => {
        const perch = perches[id];
        // Follow the org-chart rail from railOrigin -> trunk -> perch
        const { x, y } = orgPoint(railOrigin, perch, travelP, TRUNK_X);
        const fadeOut = 1 - ease(phaseProgress(time, { start: TL.dock.end - 0.2, end: TL.dock.end + 0.2 }));
        const op = fadeIn * (0.4 + 0.6 * fadeOut);
        return (
          <g key={id} transform={`translate(${x}, ${y})`} opacity={op}>
            <circle r="18" fill="#8D6E3F" opacity="0.18"/>
            <rect x="-14" y="-14" width="28" height="28" rx="2"
                  fill="#13315C" stroke="#8D6E3F" strokeWidth="1.5"/>
            <text textAnchor="middle" y="4"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="10" fontWeight="500"
                  fill="#C4A574">25%</text>
          </g>
        );
      })}
    </g>
  );
}

function BorrowerArrow({ time }) {
  const p = ease(phaseProgress(time, TL.borrowerPay));
  if (p <= 0 || p >= 1) return null;
  const startY = 600;
  const endY = 320;
  const y = startY + (endY - startY) * p;
  const op = p < 0.15 ? p / 0.15 : p > 0.8 ? (1 - p) / 0.2 : 1;
  return (
    <g transform={`translate(${NODES[0].x}, ${y})`} opacity={op}>
      <circle r="14" fill="#3F6B4E" opacity="0.2"/>
      <circle r="9" fill="#3F6B4E"/>
      <text textAnchor="middle" y="3.5"
            fontFamily="JetBrains Mono, monospace"
            fontSize="10" fontWeight="500" fill="#F5F1E8">$</text>
      <line x1="0" y1="14" x2="0" y2="46" stroke="#3F6B4E" strokeWidth="1" opacity="0.4" strokeDasharray="2 3"/>
    </g>
  );
}

function StablecoinFlow({ time }) {
  const mintP = ease(phaseProgress(time, TL.stableMint));
  const flowP = easeOut(phaseProgress(time, TL.stableFlow));
  if (time < TL.stableMint.start - 0.05) return null;
  if (time > TL.stableFlow.end + 0.3) return null;
  const mintFade = mintP < 0.5 ? mintP * 2 : 1;
  const origin = { x: NODES[0].x, y: NODES[0].y - 60 };
  return (
    <g>
      {time < TL.stableFlow.start + 0.2 && (
        <g transform={`translate(${origin.x}, ${origin.y})`} opacity={mintFade * (1 - flowP * 2 > 0 ? 1 : 0)}>
          <circle r="22" fill="rgba(63,107,78,0.18)"/>
          <circle r="16" fill="#3F6B4E" stroke="#C4A574" strokeWidth="1"/>
          <text textAnchor="middle" y="4"
                fontFamily="JetBrains Mono, monospace"
                fontSize="10" fontWeight="600" fill="#F5F1E8">USD</text>
        </g>
      )}
      {["B", "C", "D"].map((id, i) => {
        const target = NODES.find(n => n.id === id);
        const stagger = i * 0.06;
        const localP = clamp((flowP * 1.18) - stagger, 0, 1);
        if (localP <= 0) return null;
        const targetPt = { x: target.x, y: target.y - 60 };
        const eased = easeOut(localP);
        const { x, y } = orgPoint(origin, targetPt, eased, TRUNK_X);
        const op = localP < 0.1 ? localP * 10 : localP > 0.92 ? (1 - localP) * 12.5 : 1;
        return (
          <g key={id} transform={`translate(${x}, ${y})`} opacity={op}>
            <circle r="18" fill="rgba(63,107,78,0.16)"/>
            <circle r="13" fill="#3F6B4E" stroke="#C4A574" strokeWidth="1"/>
            <text textAnchor="middle" y="3.5"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="9" fontWeight="600" fill="#F5F1E8">USD</text>
          </g>
        );
      })}
      {flowP > 0 && flowP < 1 && ["B", "C", "D"].map((id, i) => {
        const target = NODES.find(n => n.id === id);
        const stagger = i * 0.06;
        const localP = clamp((flowP * 1.18) - stagger, 0, 1);
        if (localP <= 0 || localP >= 1) return null;
        const trail = 0.12;
        const targetPt = { x: target.x, y: target.y - 60 };
        const p1 = orgPoint(origin, targetPt, easeOut(Math.max(0, localP - trail)), TRUNK_X);
        const p2 = orgPoint(origin, targetPt, easeOut(localP), TRUNK_X);
        return <line key={`t-${id}`} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                     stroke="#C4A574" strokeWidth="1.5" opacity="0.5"/>;
      })}
    </g>
  );
}

function SettledBadge({ time }) {
  const p = ease(phaseProgress(time, TL.settled));
  if (p <= 0) return null;
  const fadeOut = 1 - ease(phaseProgress(time, TL.reset));
  const op = p * fadeOut;
  return (
    <g opacity={op}>
      {["B", "C", "D"].map((id) => {
        const node = NODES.find(n => n.id === id);
        return (
          <g key={id} transform={`translate(${node.x + 50}, ${node.y - 16})`}>
            <circle r="11" fill="#3F6B4E"/>
            <path d="M -4 0 L -1 3 L 5 -3" stroke="#F5F1E8" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          </g>
        );
      })}
    </g>
  );
}

function PhaseLabel({ time }) {
  const active = PHASE_LABELS.find(p => time >= p.t0 && time <= p.t1);
  const [display, setDisplay] = useState(null);
  useEffect(() => {
    if (active) setDisplay(active);
  }, [active?.text]);
  if (!display) return null;
  const cur = active;
  let op = 0;
  if (cur && cur === display) {
    const fadeIn = clamp((time - cur.t0) / 0.3, 0, 1);
    const fadeOut = clamp((cur.t1 - time) / 0.3, 0, 1);
    op = Math.min(fadeIn, fadeOut);
  }
  return (
    <div className="phase-label" style={{ opacity: op }}>
      <span className="phase-num">{display.n}</span>
      <span className="phase-text">{display.text}</span>
    </div>
  );
}

function Scrubber({ time }) {
  const marks = [
    { at: 0.4,  label: "Originate" },
    { at: 2.8,  label: "Split" },
    { at: 7.0,  label: "Pay" },
    { at: 9.2,  label: "Settle" },
  ];
  return (
    <div className="scrubber">
      <div className="scrubber-track">
        <div className="scrubber-fill" style={{ width: `${(time / LOOP_DURATION) * 100}%` }}/>
        {marks.map(m => (
          <div key={m.label} className="scrubber-mark" style={{ left: `${(m.at / LOOP_DURATION) * 100}%` }}>
            <span className="dot"/>
            <span className="label">{m.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function FlowAnimation() {
  const [time, setTime] = useState(0);
  const [started, setStarted] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const containerRef = useRef(null);
  const rafRef = useRef(null);
  const lastTsRef = useRef(null);
  const runningRef = useRef(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    const l = () => setReducedMotion(mq.matches);
    mq.addEventListener?.("change", l);
    return () => mq.removeEventListener?.("change", l);
  }, []);

  useEffect(() => {
    if (reducedMotion) { setTime(6.0); return; }
    const el = containerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      runningRef.current = entry.isIntersecting;
      if (entry.isIntersecting && !started) setStarted(true);
    }, { threshold: 0.25 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [reducedMotion, started]);

  useEffect(() => {
    if (reducedMotion || !started) return;
    const tick = (ts) => {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;
      if (runningRef.current) {
        setTime(prev => {
          const next = prev + dt;
          return next > LOOP_DURATION ? next - LOOP_DURATION : next;
        });
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
    };
  }, [started, reducedMotion]);

  return (
    <div className="flow-wrap" ref={containerRef}>
      <PhaseLabel time={time} />
      <svg className="flow-svg" viewBox="0 0 900 620" role="img"
           aria-label="Bank A originates a loan, sells three 25% participations to Banks B, C and D stacked vertically, and distributes borrower payments on-chain via USD stablecoin.">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(245,241,232,0.06)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="900" height="620" fill="url(#grid)"/>

        {/* Rails from A to B, C, D perches — org-chart orthogonal routing */}
        <Rail from={{ x: NODES[0].x, y: NODES[0].y - 60 }} to={{ x: NODES[1].x, y: NODES[1].y - 60 }} trunkX={TRUNK_X} time={time}/>
        <Rail from={{ x: NODES[0].x, y: NODES[0].y - 60 }} to={{ x: NODES[2].x, y: NODES[2].y - 60 }} trunkX={TRUNK_X} time={time}/>
        <Rail from={{ x: NODES[0].x, y: NODES[0].y - 60 }} to={{ x: NODES[3].x, y: NODES[3].y - 60 }} trunkX={TRUNK_X} time={time}/>

        {/* Borrower label below Bank A */}
        <g transform={`translate(${NODES[0].x}, 610)`}>
          <text textAnchor="middle"
                fontFamily="Inter, sans-serif"
                fontSize="10" fill="rgba(245,241,232,0.52)"
                letterSpacing="0.14em">BORROWER</text>
        </g>

        {NODES.map(n => <Node key={n.id} node={n} time={time}/>)}
        <LoanToken time={time} />
        <Shards time={time} />
        <BorrowerArrow time={time}/>
        <StablecoinFlow time={time}/>
        <SettledBadge time={time}/>
      </svg>

      <Scrubber time={time}/>
    </div>
  );
}

window.FlowAnimation = FlowAnimation;
